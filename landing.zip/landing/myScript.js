    var ancient = false;
    var nouveau = false;

    function onAncient(){
      console.log("Ancient Clicked");
      //document.getElementById('button-choice').style.display = 'none' 
      //document.getElementById('logo').style.display = 'none' 
      document.getElementById('top-jumbotron').style.display = "none";
      document.getElementById('test').innerHTML = 
                ` 
                <div class="row" style="margin-top:5%">
                          <div class="col-lg-12">
                            <div class="jumbotron">
                                <h4>Section Ancient Membres</h4>
                                <hr style="background-color: white;">
                                <p id="pToHide" style="color:white">Veuillez entrez le code pour avoir accee au fichier pdf<p>
                           
                                <input id="code" name="code" onKeyUp="getCode()" class="form-control" type="password" placeholder="4 digits" value=""/>
                                <div id="downloadPDF"> </div>
                            </div>
                          </div>
                </div>
                        `;
     
    }

     function onNouveau(){
      console.log("Nouveau Clicked");
    }

    function getCode(){
      var code = document.getElementById('code').value;
      console.log(code);
      if ( code == 4321) {
        document.getElementById('downloadPDF').innerHTML = 
        `
        <p style="color:white">Veuillez lire attentivement toutes les informations disponibles sur ce fichier, ensuite faite votre choix et votez via le lien disponible en bas du document<p>
        <button class="btn btn-block btn-success">Download</button>
        `;
        document.getElementById('code').style.display = "none";
        document.getElementById('pToHide').style.display = "none";
      }else  document.getElementById('code').classList.add('wrong');
    }
 